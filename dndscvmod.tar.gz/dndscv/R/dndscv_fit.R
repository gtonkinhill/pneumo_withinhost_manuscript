#' dndscv_fit
#'
#' @description Fit step of the analyses of selection using the dNdScv and dNdSloc models.
#'
#' @author Inigo Martincorena (Wellcome Sanger Institute)
#' @details Martincorena I, et al. (2017) Universal patterns of selection in cancer and somatic tissues. Cell. 171(5):1029-1041.
#'
#' @param RefCDS
#' @param substmodel
#'
#' @export
dndscv_fit <- function(RefCDS, indels=data.frame(),
                       cv = "hg19",
                       sm = "192r_3w",
                       max_muts_per_gene_per_sample = 3,
                       max_coding_muts_per_sample = 3000,
                       use_indel_sites = TRUE,
                       min_indels = 5,
                       maxcovs = 20,
                       constrain_wnon_wspl = TRUE,
                       outp = 3,
                       numcode = 1,
                       outmats = FALSE){

    # [Input] Substitution model (The user can also input a custom substitution model as a matrix)
    if (length(sm)==1) {
        data(list=sprintf("submod_%s",sm), package="dndscv")
    } else {
        substmodel = sm
    }

    ## 3. Estimation of the global rate and selection parameters
    message("[3] Estimating global rates...")

    Lall = array(sapply(RefCDS, function(x) x$L), dim=c(192,4,length(RefCDS)))
    Nall = array(sapply(RefCDS, function(x) x$N), dim=c(192,4,length(RefCDS)))
    L = apply(Lall, c(1,2), sum)
    N = apply(Nall, c(1,2), sum)

    # Fitting all mutation rates and the 3 global selection parameters

    poissout = fit_substmodel(N, L, substmodel) # Original substitution model
    par = poissout$par
    poissmodel = poissout$model
    parmle =  setNames(par[,2], par[,1])
    mle_submodel = par
    rownames(mle_submodel) = NULL

    # Fitting models with 1 and 2 global selection parameters

    s1 = gsub("wmis","wall",gsub("wnon","wall",gsub("wspl","wall",substmodel)))
    par1 = fit_substmodel(N, L, s1)$par # Substitution model with 1 selection parameter
    s2 = gsub("wnon","wtru",gsub("wspl","wtru",substmodel))
    par2 = fit_substmodel(N, L, s2)$par # Substitution model with 2 selection parameter
    globaldnds = rbind(par, par1, par2)[c("wmis","wnon","wspl","wtru","wall"),]
    sel_loc = sel_cv = NULL

    ## 4. dNdSloc: variable rate dN/dS model (gene mutation rate inferred from synonymous subs in the gene only)

    genemuts = data.frame(gene_name = sapply(RefCDS, function(x) x$gene_name), n_syn=NA, n_mis=NA, n_non=NA, n_spl=NA, exp_syn=NA, exp_mis=NA, exp_non=NA, exp_spl=NA, stringsAsFactors=F)
    genemuts[,2:5] = t(sapply(RefCDS, function(x) colSums(x$N)))
    mutrates = sapply(substmodel[,1], function(x) prod(parmle[base::strsplit(x,split="\\*")[[1]]])) # Expected rate per available site
    genemuts[,6:9] = t(sapply(RefCDS, function(x) colSums(x$L*mutrates)))
    numrates = length(mutrates)

    if (outp > 1) {
        message("[4] Running dNdSloc...")

        sel_loc = as.data.frame(t(sapply(1:nrow(genemuts), function(k) selfun_loc(RefCDS[[k]], as.numeric(genemuts[k,-1]),
                                                                                  mutrates, mrfold, numrates))))
        colnames(sel_loc) = c("wmis_loc","wnon_loc","wspl_loc","pmis_loc","pall_loc",
                              "upper1","upper2","upper3","lower1","lower2","lower3")
        sel_loc$qmis_loc = p.adjust(sel_loc$pmis_loc, method="BH")
        sel_loc$qall_loc = p.adjust(sel_loc$pall_loc, method="BH")
        sel_loc = cbind(genemuts[,1:5],sel_loc)
        sel_loc = sel_loc[order(sel_loc$pall_loc,sel_loc$pmis_loc,-sel_loc$wmis_loc),]
    }


    ## 5. dNdScv: Negative binomial regression (with or without covariates) + local synonymous mutations

    nbreg = nbregind = NULL
    if (outp > 2) {

        message("[5] Running dNdScv...")

        # Covariates
        if (is.null(cv)) {
            nbrdf = genemuts[,c("n_syn","exp_syn")]
            model = MASS::glm.nb(n_syn ~ offset(log(exp_syn)) - 1 , data = nbrdf)
            message(sprintf("    Regression model for substitutions: no covariates were used (theta = %0.3g).", model$theta))
        } else {
            covs = covs[genemuts$gene_name,]
            if (ncol(covs) > maxcovs) {
                warning(sprintf("More than %s input covariates. Only the first %s will be considered.", maxcovs, maxcovs))
                covs = covs[,1:maxcovs]
            }
            nbrdf = cbind(genemuts[,c("n_syn","exp_syn")], covs)

            # Negative binomial regression for substitutions
            if (nrow(genemuts)<500) { # If there are <500 genes, we run the regression without covariates
                model = MASS::glm.nb(n_syn ~ offset(log(exp_syn)) - 1 , data = nbrdf)
            } else {
                model = tryCatch({
                    MASS::glm.nb(n_syn ~ offset(log(exp_syn)) + . , data = nbrdf) # We try running the model with covariates
                }, warning = function(w){
                    MASS::glm.nb(n_syn ~ offset(log(exp_syn)) - 1 , data = nbrdf) # If there are warnings or errors we run the model without covariates
                }, error = function(e){
                    MASS::glm.nb(n_syn ~ offset(log(exp_syn)) - 1 , data = nbrdf) # If there are warnings or errors we run the model without covariates
                })
            }
            message(sprintf("    Regression model for substitutions (theta = %0.3g).", model$theta))
        }
        if (all(model$y==genemuts$n_syn)) {
            genemuts$exp_syn_cv = model$fitted.values
        }
        theta = model$theta
        nbreg = model

        sel_cv = as.data.frame(t(sapply(1:nrow(genemuts), function(i) selfun_cv(i, genemuts, theta, mutrates,
                                                                                numrates, constrain_wnon_wspl,
                                                                                RefCDS))))
        colnames(sel_cv) = c("wmis_cv","wnon_cv","wspl_cv","pmis_cv","ptrunc_cv","pallsubs_cv")
        sel_cv$qmis_cv = p.adjust(sel_cv$pmis_cv, method="BH")
        sel_cv$qtrunc_cv = p.adjust(sel_cv$ptrunc_cv, method="BH")
        sel_cv$qallsubs_cv = p.adjust(sel_cv$pallsubs_cv, method="BH")
        sel_cv = cbind(genemuts[,1:5],sel_cv)
        sel_cv = sel_cv[order(sel_cv$pallsubs_cv, sel_cv$pmis_cv, sel_cv$ptrunc_cv, -sel_cv$wmis_cv),] # Sorting genes in the output file

        ## Indel recurrence: based on a negative binomial regression (ideally fitted excluding major known driver genes)

        if (nrow(indels) >= min_indels) {

            geneindels = as.data.frame(array(0,dim=c(length(RefCDS),8)))
            colnames(geneindels) = c("gene_name","n_ind","n_induniq","n_indused","cds_length","excl","exp_unif","exp_indcv")
            geneindels$gene_name = sapply(RefCDS, function(x) x$gene_name)
            geneindels$n_ind = as.numeric(table(indels$gene)[geneindels[,1]]); geneindels[is.na(geneindels[,2]),2] = 0
            geneindels$n_induniq = as.numeric(table(unique(indels[,-1])$gene)[geneindels[,1]]); geneindels[is.na(geneindels[,3]),3] = 0
            geneindels$cds_length = sapply(RefCDS, function(x) x$CDS_length)

            if (use_indel_sites) {
                geneindels$n_indused = geneindels[,3]
            } else {
                geneindels$n_indused = geneindels[,2]
            }

            # Excluding known cancer genes (first using the input or the default list, but if this fails, we use a shorter data-driven list)
            geneindels$excl = (geneindels[,1] %in% known_cancergenes)
            min_bkg_genes = 50
            if (sum(!geneindels$excl)<min_bkg_genes | sum(geneindels[!geneindels$excl,"n_indused"]) == 0) { # If the exclusion list is too restrictive (e.g. targeted sequencing of cancer genes), then identify a shorter list of selected genes using the substitutions.
                newkc = as.vector(sel_cv$gene_name[sel_cv$qallsubs_cv<0.01])
                geneindels$excl = (geneindels[,1] %in% newkc)
                if (sum(!geneindels$excl)<min_bkg_genes | sum(geneindels[!geneindels$excl,"n_indused"]) == 0) { # If the new exclusion list is still too restrictive, then do not apply a restriction.
                    geneindels$excl = F
                    message("    No gene was excluded from the background indel model.")
                } else {
                    warning(sprintf("    Genes were excluded from the indel background model based on the substitution data: %s.", paste(newkc, collapse=", ")))
                }
            }

            geneindels$exp_unif = sum(geneindels[!geneindels$excl,"n_indused"]) / sum(geneindels[!geneindels$excl,"cds_length"]) * geneindels$cds_length

            # Negative binomial regression for indels

            if (is.null(cv)) {
                nbrdf = geneindels[,c("n_indused","exp_unif")][!geneindels[,6],] # We exclude known drivers from the fit
                model = MASS::glm.nb(n_indused ~ offset(log(exp_unif)) - 1 , data = nbrdf)
                nbrdf_all = geneindels[,c("n_indused","exp_unif")]
            } else {
                nbrdf = cbind(geneindels[,c("n_indused","exp_unif")], covs)[!geneindels[,6],] # We exclude known drivers from the fit
                if (sum(!geneindels$excl)<500) { # If there are <500 genes, we run the regression without covariates
                    model = MASS::glm.nb(n_indused ~ offset(log(exp_unif)) - 1 , data = nbrdf)
                } else {
                    model = tryCatch({
                        MASS::glm.nb(n_indused ~ offset(log(exp_unif)) + . , data = nbrdf) # We try running the model with covariates
                    }, warning = function(w){
                        MASS::glm.nb(n_indused ~ offset(log(exp_unif)) - 1 , data = nbrdf) # If there are warnings or errors we run the model without covariates
                    }, error = function(e){
                        MASS::glm.nb(n_indused ~ offset(log(exp_unif)) - 1 , data = nbrdf) # If there are warnings or errors we run the model without covariates
                    })
                }
                nbrdf_all = cbind(geneindels[,c("n_indused","exp_unif")], covs)
            }
            message(sprintf("    Regression model for indels (theta = %0.3g)", model$theta))

            theta_indels = model$theta
            nbregind = model
            geneindels$exp_indcv = exp(predict(model,nbrdf_all))
            geneindels$wind = geneindels$n_indused / geneindels$exp_indcv

            # Statistical testing for indel recurrence per gene

            geneindels$pind = pnbinom(q=geneindels$n_indused-1, mu=geneindels$exp_indcv, size=theta_indels, lower.tail=F)
            geneindels$qind = p.adjust(geneindels$pind, method="BH")

            # Fisher combined p-values (substitutions and indels)

            sel_cv = merge(sel_cv, geneindels, by="gene_name")[,c("gene_name","n_syn","n_mis","n_non","n_spl","n_indused","wmis_cv","wnon_cv","wspl_cv","wind","pmis_cv","ptrunc_cv","pallsubs_cv","pind","qmis_cv","qtrunc_cv","qallsubs_cv")]
            colnames(sel_cv) = c("gene_name","n_syn","n_mis","n_non","n_spl","n_ind","wmis_cv","wnon_cv","wspl_cv","wind_cv","pmis_cv","ptrunc_cv","pallsubs_cv","pind_cv","qmis_cv","qtrunc_cv","qallsubs_cv")
            sel_cv$pglobal_cv = 1 - pchisq(-2 * (log(sel_cv$pallsubs_cv) + log(sel_cv$pind_cv)), df = 4)
            sel_cv$qglobal_cv = p.adjust(sel_cv$pglobal, method="BH")

            sel_cv = sel_cv[order(sel_cv$pglobal_cv, sel_cv$pallsubs_cv, sel_cv$pmis_cv, sel_cv$ptrunc_cv, -sel_cv$wmis_cv),] # Sorting genes in the output file
        }
    }



    if (outmats) {
        dndscvout = list(globaldnds = globaldnds, sel_cv = sel_cv, sel_loc = sel_loc,
                         genemuts = genemuts, mle_submodel = mle_submodel,
                         nbreg = nbreg, nbregind = nbregind, poissmodel = poissmodel,
                         N = Nall, L = Lall)
    } else {
        dndscvout = list(globaldnds = globaldnds, sel_cv = sel_cv, sel_loc = sel_loc,
                         genemuts = genemuts, mle_submodel = mle_submodel,
                         nbreg = nbreg, nbregind = nbregind, poissmodel = poissmodel)
    }

} # EOF
