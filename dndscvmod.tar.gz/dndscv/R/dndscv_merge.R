#' dndscv_merge
#'
#' @description merge annotation files from different runs of dndscv_annotate
#'
#' @author Gerry Tonkin-Hill
#' @details Martincorena I, et al. (2017) Universal patterns of selection in cancer and somatic tissues. Cell. 171(5):1029-1041.
#'
#' @param RefCDSs
#' @param clusters
#'
#' @export
dndscv_merge <- function(RefCDSs, clusters){
    clusters <- clusters[!(is.na(clusters$geneid) | is.na(clusters$cluster)),]
    ids <- unique(clusters$cluster)

    indexes <- purrr::map2_dfr(1:length(RefCDSs), RefCDSs, function(i,RefCDS){
        tibble::tibble(index=i,
               cds=purrr::map(RefCDS, ~ .x),
               geneid=purrr::map_chr(RefCDS, function(g) g$gene_id))
    })

    mergedRef <- purrr::map(ids, ~{
        gene_pid <- clusters$geneid[clusters$cluster==.x]

        # copies <- purrr::map(RefCDSs, function(RefCDS){
        #     cop <- RefCDS[purrr::map_lgl(RefCDS, function(g) g$gene_id %in% gene_pid)]
        #     if (length(cop)>0){
        #         return(cop[[1]])
        #     }
        #     return(NULL)
        # })
        # copies <- copies[map_lgl(copies, ~ length(.x)>0)]

        copies <- indexes[indexes$geneid %in% gene_pid,]
        copies <- copies$cds[!duplicated(copies$index)]

        if (length(copies)<1) return(NULL)

        new <- copies[[1]]

        Lall = array(sapply(copies, function(x) x$L), dim=c(192,4,length(copies)))
        Nall = array(sapply(copies, function(x) x$N), dim=c(192,4,length(copies)))

        new$L <- apply(Lall, c(1,2), sum)
        new$N <- apply(Nall, c(1,2), sum)

        new$all_pids <- map_chr(copies, function(g) g$gene_name)
        new$all_genes <- map_chr(copies, function(g) g$gene_id)
        new$gene_name <- .x
        new$gene_id <- .x

        return(new)
    })

    mergedRef <- mergedRef[!purrr::map_lgl(mergedRef, is.null)]

    return(mergedRef)
}
