#' selfun_loc
#'
#' @description subfunction
#'
#' @param x gene entry in RefDS
#' @param u corresponding genemuts entry
#'
#' @return
#'
selfun_loc = function(x, y, mutrates, mrfold, numrates) {
    # y = as.numeric(genemuts[j,-1])
    # x = RefCDS[[j]]

    # a. Neutral model: wmis==1, wnon==1, wspl==1
    mrfold = sum(y[1:4])/sum(y[5:8]) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    ll0 = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,1,1,1),dim=c(4,numrates))), log=TRUE)) # loglik null model

    # b. Missense model: wmis==1, free wnon, free wspl
    mrfold = max(1e-10, sum(y[c(1,2)])/sum(y[c(5,6)])) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    wfree = y[3:4]/y[7:8]/mrfold; wfree[y[3:4]==0] = 0
    llmis = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,1,wfree),dim=c(4,numrates))), log=TRUE)) # loglik free wmis

    # c. free wmis, wnon and wspl
    mrfold = max(1e-10, y[1]/y[5]) # Correction factor of "t"
    w = y[2:4]/y[6:8]/mrfold; w[y[2:4]==0] = 0 # MLE of dN/dS based on the local rate (using syn muts as neutral)
    llall = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,w),dim=c(4,numrates))), log=TRUE)) # loglik free wmis, wnon, wspl
    w[w>1e4] = 1e4

    p = 1-pchisq(2*(llall-c(llmis,ll0)),df=c(1,3))

    ci <- map_dfr(2:4, ~ {
        optf <- function(rate) return(abs(abs(sum(dpois(x=x$N[,.x], lambda=x$L[,.x]*mutrates*mrfold*w[[.x-1]], log=TRUE)) -
                                                  sum(dpois(x=x$N[,.x], lambda=x$L[,.x]*mutrates*mrfold*rate, log=TRUE))) - 1.92))

        return(tibble::tibble(
            upper = optimise(optf, lower = w[[.x-1]], upper = 1e50)$minimum,
            lower = optimise(optf, lower = 0, upper = w[[.x-1]]+1e-10)$minimum
        ))
    })

    return(c(w,p,unlist(ci)))
}


