#' selfun_cv
#'
#' @description Subfunction: dNdScv per gene
#'
#' @param j gene number
#' @param genemuts
#' @param theta
#' @param mutrates
#' @param numrates
#' @param constrain_wnon_wspl
#' @param RefCDS
#'
#' @return
#'
selfun_cv = function(j, genemuts, theta, mutrates, numrates, constrain_wnon_wspl, RefCDS) {
    y = as.numeric(genemuts[j,-1])
    x = RefCDS[[j]]
    exp_rel = y[5:8]/y[5]
    # Gamma
    shape = theta
    scale = y[9]/theta

    # a. Neutral model
    indneut = 1:4 # vector of neutral mutation types under this model (1=synonymous, 2=missense, 3=nonsense, 4=essential_splice)
    opt_t = mle_tcv(n_neutral=sum(y[indneut]), exp_rel_neutral=sum(exp_rel[indneut]), shape=shape, scale=scale)
    mrfold = max(1e-10, opt_t/y[5]) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    ll0 = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,1,1,1),dim=c(4,numrates))), log=TRUE)) + dgamma(opt_t, shape=shape, scale=scale, log=TRUE) # loglik null model

    # b. Missense model: wmis==1, free wnon, free wspl
    indneut = 1:2
    opt_t = mle_tcv(n_neutral=sum(y[indneut]), exp_rel_neutral=sum(exp_rel[indneut]), shape=shape, scale=scale)
    mrfold = max(1e-10, opt_t/sum(y[5])) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    wfree = y[3:4]/y[7:8]/mrfold; wfree[y[3:4]==0] = 0
    llmis = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,1,wfree),dim=c(4,numrates))), log=TRUE)) + dgamma(opt_t, shape=shape, scale=scale, log=TRUE) # loglik free wmis

    # c. Truncating muts model: free wmis, wnon==wspl==1
    indneut = c(1,3,4)
    opt_t = mle_tcv(n_neutral=sum(y[indneut]), exp_rel_neutral=sum(exp_rel[indneut]), shape=shape, scale=scale)
    mrfold = max(1e-10, opt_t/sum(y[5])) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    wfree = y[2]/y[6]/mrfold; wfree[y[2]==0] = 0
    lltrunc = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,wfree,1,1),dim=c(4,numrates))), log=TRUE)) + dgamma(opt_t, shape=shape, scale=scale, log=TRUE) # loglik free wmis

    # d. Free selection model: free wmis, free wnon, free wspl
    indneut = 1
    opt_t = mle_tcv(n_neutral=sum(y[indneut]), exp_rel_neutral=sum(exp_rel[indneut]), shape=shape, scale=scale)
    mrfold = max(1e-10, opt_t/sum(y[5])) # Correction factor of "t" based on the obs/exp ratio of "neutral" mutations under the model
    wfree = y[2:4]/y[6:8]/mrfold; wfree[y[2:4]==0] = 0
    llall_unc = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,wfree),dim=c(4,numrates))), log=TRUE)) + dgamma(opt_t, shape=shape, scale=scale, log=TRUE) # loglik free wmis

    if (constrain_wnon_wspl == 0) {

        p = 1-pchisq(2*(llall_unc-c(llmis,lltrunc,ll0)),df=c(1,2,3))
        return(c(wfree,p))

    } else { # d2. Free selection model: free wmis, free wnon==wspl

        wmisfree = y[2]/y[6]/mrfold; wmisfree[y[2]==0] = 0
        wtruncfree = sum(y[3:4])/sum(y[7:8])/mrfold; wtruncfree[sum(y[3:4])==0] = 0
        llall = sum(dpois(x=x$N, lambda=x$L*mutrates*mrfold*t(array(c(1,wmisfree,wtruncfree,wtruncfree),dim=c(4,numrates))), log=TRUE)) + dgamma(opt_t, shape=shape, scale=scale, log=TRUE) # loglik free wmis, free wnon==wspl
        p = 1-pchisq(2*c(llall_unc-llmis,llall-c(lltrunc,ll0)),df=c(1,1,2))
        return(c(wmisfree,wtruncfree,wtruncfree,p))
    }
}
