#' fit_substmodel
#'
#' @description Subfunction: fitting substitution model
#'
#' @param N
#' @param L
#' @param substmodel
#'
#' @return
#'
fit_substmodel = function(N, L, substmodel) {

    l = c(L); n = c(N); r = c(substmodel)
    n = n[l!=0]; r = r[l!=0]; l = l[l!=0]

    params = unique(base::strsplit(x=paste(r,collapse="*"), split="\\*")[[1]])
    indmat = as.data.frame(array(0, dim=c(length(r),length(params))))
    colnames(indmat) = params
    for (j in 1:length(r)) {
        indmat[j, base::strsplit(r[j], split="\\*")[[1]]] = 1
    }

    model = glm(formula = n ~ offset(log(l)) + . -1, data=indmat, family=poisson(link=log))
    mle = exp(coefficients(model)) # Maximum-likelihood estimates for the rate params
    ci = exp(confint.default(model)) # Wald confidence intervals
    par = data.frame(name=gsub("\`","",rownames(ci)), mle=mle[rownames(ci)], cilow=ci[,1], cihigh=ci[,2])
    return(list(par=par, model=model))
}
