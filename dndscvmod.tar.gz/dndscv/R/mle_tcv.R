#' mle_tcv
#'
#'  @description Subfunction: Analytical opt_t using only neutral subs
#'
#'  @param n_neutral
#'  @param exp_rel_neutral
#'  @param shape
#'  @param scale
#'
mle_tcv = function(n_neutral, exp_rel_neutral, shape, scale) {
    tml = (n_neutral+shape-1)/(exp_rel_neutral+(1/scale))
    if (shape<=1) { # i.e. when theta<=1
        tml = max(shape*scale,tml) # i.e. tml is bounded to the mean of the gamma (i.e. y[9]) when theta<=1, since otherwise it takes meaningless values
    }
    return(tml)
}
